## usethis namespace: start
#' @importFrom assertthat %has_name%
#' @importFrom assertthat assert_that
#' @importFrom dplyr if_else
#' @importFrom Rcpp sourceCpp
#' @useDynLib bayestransmission, .registration = TRUE
## usethis namespace: end
NULL
