Rcpp::loadModule("BayesianInfectiousDiseaseModelingModule", TRUE)
# Rcpp::loadModule("lognormal_cpp_module", TRUE)
