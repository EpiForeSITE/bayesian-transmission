
class LTCFCoding
{
public:

	static Map *sysisol;
	static Map *syseverisol;
};

Map *LTCFCoding::sysisol = new Map();
Map *LTCFCoding::syseverisol = new Map();
