
#include "lognormal/lognormal.h"
#include <Rcpp.h>

class RMixedModel : lognormal::MixedModel{



};


