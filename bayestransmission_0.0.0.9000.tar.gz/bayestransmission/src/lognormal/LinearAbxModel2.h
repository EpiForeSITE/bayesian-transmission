#ifndef ALUN_LOGNORMAL_LINEARABXMODEL2_H
#define ALUN_LOGNORMAL_LINEARABXMODEL2_H

class LinearAbxModel2 : public LogNormalModel
{
public:
    LinearAbxModel2(int nst, int nmetro, int fw, int ch);
};

#endif // ALUN_LOGNORMAL_LINEARABXMODEL2_H
